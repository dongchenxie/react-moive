import React, { useState, useEffect } from 'react';
import { fetchApp } from './fetch';
import { MoiveComponent } from './moiveComponent';
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link,
    useParams
} from "react-router-dom";
export const MoivePage = (props) => {
    //setcontext("12")
    const [movieData, setMoiveData] = useState(null)
    let { id } = useParams();
    useEffect(async () => {
        
        console.log("user effect")
        fetchApp(setMoiveData, "/movie/" +id)
    }, []);

    if (movieData) {
        return (<div className="container">
            <h1 className="header vl">{movieData.title}</h1>
            <div className="movie-content row">
                <div className="poster col s12 m5" style={{ backgroundImage: "https://image.tmdb.org/t/p/w500/" + movieData.poster_path, }}>
                    <img src={"https://image.tmdb.org/t/p/w500/" + movieData.poster_path} style={{ height: "50rem" }}></img>
                </div>
                <div className="movie-text col s12 m6">
                    <p>{"Release Date: " + movieData.release_date}</p>
                </div>
            </div>
        </div>)
    } else {
        return <div className="progress">
            <div className="determinate" style={{ width: "70%" }}></div>
        </div>
    }

} 
