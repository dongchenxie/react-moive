import React from 'react';

export const Rated=(props)=>{
    //setcontext("12")
return <h1>rated{props.name}</h1>
} 
