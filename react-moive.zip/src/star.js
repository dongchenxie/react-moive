import React from 'react';
const star =  <i class="material-icons ">star</i>
const starHalf = <i class="material-icons">star_half</i>
const starBorader =  <i class="material-icons">star_border</i>
export const Star= (props) => {
    let maxStars = props.maxStars
    let maxScore = props.maxScore
    let score = props.score
    let scorePerStar = maxScore / maxStars
    let returnItem = []
    let fullstar=Math.floor(score / scorePerStar)
    let halfstar=(score / scorePerStar)-fullstar;
    for(let i=0;i<maxStars;i++){
        if(fullstar>0){
            returnItem.push(star)
            fullstar--
        }else if(halfstar>=0.5){
            returnItem.push(starHalf)
            halfstar=halfstar-0.5
        }else{
            returnItem.push(starBorader)
        }
    }
    // for (let i = maxScore; i > 0; i++) {
    //     score -= scorePerStar;
    //     if (score > scorePerStar) {
            
    //         returnItem.push(star)
    //     } else if (score > (scorePerStar / 2)) {
            
    //         returnItem.push(starHalf)
    //     } else {
            
    //         returnItem.push(starBorader)
    //     }
    // }
    return (<a className="stars amber-text text-darken-1">
        <span>{returnItem}</span>
    </a>)

}
