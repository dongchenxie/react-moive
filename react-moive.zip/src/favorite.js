import React from 'react';

export const Favorite=(props)=>{
    //setcontext("12")
return <h1> Favorite{props.name}</h1>
} 
